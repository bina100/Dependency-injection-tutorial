package com.example.L93105.services;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

public interface GreetingService {
      String getGreeting();
}
