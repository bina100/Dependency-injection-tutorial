package com.example.L93105.services;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

//הגדרת שם ל bean כדי שידע לגשת ל english ולא ל spain
@Profile("EN")
@Service("i18nService")
public class I18nEnglishService implements GreetingService{


    @Override
    public String getGreeting() {
        return "Yo- English";
    }
}
